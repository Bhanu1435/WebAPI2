﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TestAPI
{
    class Program
    {
        static void Main(string[] args)
        {
            string baseAddress = "http://localhost:61303/";

            HttpClient client = new HttpClient();
            string input = Console.ReadLine();

            HttpResponseMessage response = client.GetAsync(baseAddress + "api/HalloWorld/" + input).Result;

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Request Message Information:- \n\n" + response.RequestMessage + "\n");
                Console.WriteLine("Response Message Header \n\n" + response.Content.Headers + "\n");
                
            }


            Console.ReadLine();
        }
    }
}
